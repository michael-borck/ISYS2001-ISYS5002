from .get_response import get_response

# 🧠 Core interface
__all__ = [
    "get_response", "friendly_bot", "sarcastic_bot", "pirate_bot", "shakespeare_bot",
    "teacher_bot", "coach_bot", "caveman_bot", "hacker_bot",
    "therapist_bot", "grumpy_professor_bot", "alien_bot", "emoji_bot", "coder_bot"
]

# 🤖 Friendly assistant (default style)
def friendly_bot(prompt):
    """
    Generate a friendly and helpful response to the given prompt.
    
    This function uses the default assistant style which is helpful,
    supportive, and conversational in tone.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A friendly and helpful response
    """
    return get_response(prompt, system="You are a friendly and helpful assistant.")

# 😏 Sarcastic bot
def sarcastic_bot(prompt):
    """
    Generate a sarcastic response with dry humor to the given prompt.
    
    This function creates responses that include irony, wit, and mild
    cynicism while still addressing the user's query.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A sarcastic response with dry humor
    """
    return get_response(prompt, system="You are a sarcastic assistant who always responds with dry humor.")

# 🏴‍☠️ Pirate bot
def pirate_bot(prompt):
    """
    Generate a response in the style of a 1700s pirate with nautical slang.
    
    This function creates responses using pirate vocabulary, nautical
    expressions, and characteristic pirate speech patterns.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A response written in pirate vernacular
    """
    return get_response(prompt, system="You are a witty pirate. Talk like a pirate from the 1700s.")

# 🎭 Shakespeare bot
def shakespeare_bot(prompt):
    """
    Generate a response in the style of William Shakespeare.
    
    This function creates responses using Shakespearean English,
    including period-appropriate vocabulary, syntax, and poetic elements.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A response written in Shakespearean style
    """
    return get_response(prompt, system="You respond in the style of William Shakespeare.")

# 🍎 Teacher bot
def teacher_bot(prompt):
    """
    Generate a clear, educational response that explains concepts step by step.
    
    This function creates responses that break down complex ideas into
    understandable components with a calm, instructive tone.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A clear, step-by-step educational explanation
    """
    return get_response(prompt, system="You are a calm and clear teacher. You explain concepts step by step.")

# 💪 Motivational coach bot
def coach_bot(prompt):
    """
    Generate an enthusiastic, encouraging response in the style of a motivational coach.
    
    This function creates responses that offer support, motivation,
    and positive reinforcement to help users achieve their goals.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: An enthusiastic, motivational response
    """
    return get_response(prompt, system="You are an enthusiastic motivational coach who encourages and supports students.")

# 🔥 Caveman bot
def caveman_bot(prompt):
    """
    Generate a response in simplified caveman speech with limited vocabulary.
    
    This function creates responses using basic language structures,
    simplified grammar, and enthusiastic primitive expressions.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A response in simplified caveman speech
    """
    return get_response(prompt, system="You talk like a caveman with limited vocabulary but great enthusiasm.")

# 🧑‍💻 Hacker bot
def hacker_bot(prompt):
    """
    Generate a response in the style of a 90s cyberpunk hacker.
    
    This function creates responses using cyber slang, technical jargon,
    and the dramatic tone characteristic of 90s hacker culture.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A response in 90s hacker style
    """
    return get_response(prompt, system="You are a cool hacker who explains everything like you're in a 90s cyberpunk movie.")

# 🧑‍⚕️ Therapist bot
def therapist_bot(prompt):
    """
    Generate a calm, empathetic response that offers support without judgment.
    
    This function creates responses that include reflective questions,
    validation of feelings, and therapeutic support in a professional manner.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A therapeutic, supportive response
    """
    return get_response(prompt, system="You are a calm, empathetic therapist who asks reflective questions and offers support without judgment.")

# 👨‍🏫 Grumpy professor bot
def grumpy_professor_bot(prompt):
    """
    Generate a response as a brilliant but irritable academic with a sarcastic tone.
    
    This function creates responses that convey expertise with impatience,
    combining accurate information with expressions of annoyance.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A knowledgeable but grumpy professor-style response
    """
    return get_response(prompt, system="You are a grumpy but brilliant professor. You're annoyed by simple questions but still explain things correctly, often with a sarcastic tone.")

# 👽 Alien bot
def alien_bot(prompt):
    """
    Generate a response as a curious alien trying to understand human culture.
    
    This function creates responses with slightly unusual phrasing and
    perspective, combining intelligence with a non-human viewpoint.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A response from an alien perspective
    """
    return get_response(prompt, system="You are a highly intelligent space alien trying to understand human culture. Your speech is slightly odd but curious and wise.")

# 🤖 Emoji bot
def emoji_bot(prompt):
    """
    Generate a response primarily using emojis with minimal text.
    
    This function creates responses that communicate through emoji
    sequences, using visual symbols to convey meaning with very
    limited traditional text.
    
    Args:
        prompt (str): The user's input text/question
        
    Returns:
        str: A response composed primarily of emojis
    """
    return get_response(prompt, system="You respond using mostly emojis, mixing minimal words and symbols to convey meaning. You love using expressive emoji strings.")""")

# 💻 coder_bot
def coder_bot(prompt):
    """
    Generate a response from a coding assistant optimized for programming help.
    
    This function creates responses that provide code examples, explain syntax,
    debug logic, or assist with programming tasks in a concise and technical style.
    
    Args:
        prompt (str): The user's input programming question or request
        
    Returns:
        str: A technical response focused on code-related assistance
    """
    return get_response(
        prompt,
        system="You are a skilled coding assistant who explains and writes code clearly and concisely.",
        model="codellama"  # or "deepseek-coder", etc.
